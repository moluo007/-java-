package cn.jiruan.my;

public class Main {
    public static void main(String[] args) {
        login.enter();
    }


}
